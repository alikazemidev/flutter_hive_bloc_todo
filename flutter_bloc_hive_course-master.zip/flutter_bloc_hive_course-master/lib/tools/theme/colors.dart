import 'package:flutter/material.dart';

final primaryColor = Colors.purple.shade200;
const backGroundColor = Colors.white;
const textFieldColor = Color(0xFFF1F2F4);

const darkColor = Color(0xff3D3F47);
const redColor = Color(0xffea504c);
const borderColor = Color(0xFF979ba3);

const whiteColor = Colors.white;
final greyColor = Colors.grey.shade300;
