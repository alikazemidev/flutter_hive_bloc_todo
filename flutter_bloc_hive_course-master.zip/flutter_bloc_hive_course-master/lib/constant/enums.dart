enum Sort {
  sortBySubmitDate,
  sortByGoalDate,
  sortByIsDone,
  sortByIsNotDone,
}
