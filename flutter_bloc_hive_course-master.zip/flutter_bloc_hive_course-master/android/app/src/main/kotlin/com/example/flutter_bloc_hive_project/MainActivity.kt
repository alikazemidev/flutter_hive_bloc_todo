package com.example.flutter_bloc_hive_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
